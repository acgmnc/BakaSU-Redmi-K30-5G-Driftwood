// SPDX-License-Identifier: GPL-2.0-only
/*
 * Copyright (C) 2026 \xx
 *
 * This file is a downstream extension and NOT affiliated, endorsed by,
 * or maintained by the official KernelSU developers.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 */

int ksu_inode_rename(struct inode *old_inode, struct dentry *old_dentry,
			    struct inode *new_inode, struct dentry *new_dentry)
{
	ksu_rename_observer(old_dentry, new_dentry);
	return 0;
}

int ksu_task_fix_setuid(struct cred *new, const struct cred *old, int flags)
{
#ifndef CONFIG_KSU_SUSFS
	// see sys_setresuid
	if (flags == LSM_SETID_RES)
		ksu_handle_setresuid_cred(new, old);
#endif
	return 0;
}

int ksu_bprm_check(struct linux_binprm *bprm)
{
	return 0;
}

int ksu_file_permission(struct file *file, int mask)
{
#if !defined(CONFIG_KSU_TAMPER_SYSCALL_TABLE) && !defined(CONFIG_KSU_SUSFS)
#ifdef KSU_CAN_USE_JUMP_LABEL
	if (static_branch_likely(&ksud_vfs_read_key))
		ksu_install_rc_hook(file);
#else
	if (unlikely(ksu_vfs_read_hook))
		ksu_install_rc_hook(file);
#endif
#endif

	ksu_mount_hide_file_permission(file, mask);

	return 0;
}

static bool lsm_procattr_hook __read_mostly = true;
int ksu_hide_setprocattr(const char *name, void *value, size_t size)
{
	if (lsm_procattr_hook)
		ksu_hide_setprocattr_inline(name, value, size);
	return 0;
}

// NOTE: 4-args only. other args unused.
static bool lsm_setxattr_hook __read_mostly = true;
int ksu_hide_inode_setxattr(struct dentry *dentry, const char *name, void *value, size_t *size, int *flags)
{
	if (lsm_setxattr_hook)
		ksu_hide_setxattr_inline(name, value, *size);
	return 0;
}

static void __init ksu_lsm_hook_init(void)
{
	pr_info("%s: Automated LSM hooking disabled. Make sure manual security hooks are implemented!\n", __func__);
}

static void ksu_decide_inode_setxattr(bool sh_hooked)
{
	if (!sh_hooked)
		return;
	lsm_setxattr_hook = false;
	pr_info("LSM: security_inode_setxattr unhooked!\n");
}
static void ksu_decide_setprocattr(bool sh_hooked)
{
	if (!sh_hooked)
		return;
	lsm_procattr_hook = false;
	pr_info("LSM: security_inode_procattr unhooked!\n");
}

